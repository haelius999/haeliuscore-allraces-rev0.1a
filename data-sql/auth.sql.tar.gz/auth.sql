-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.7.30 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             12.0.0.6468
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for acore_auth
CREATE DATABASE IF NOT EXISTS `acore_auth` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `acore_auth`;

-- Dumping structure for table acore_auth.account
CREATE TABLE IF NOT EXISTS `account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `username` varchar(32) NOT NULL DEFAULT '',
  `salt` binary(32) NOT NULL,
  `verifier` binary(32) NOT NULL,
  `session_key` binary(40) DEFAULT NULL,
  `totp_secret` varbinary(128) DEFAULT NULL,
  `email` varchar(255) NOT NULL DEFAULT '',
  `reg_mail` varchar(255) NOT NULL DEFAULT '',
  `joindate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `last_attempt_ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `failed_logins` int(10) unsigned NOT NULL DEFAULT '0',
  `locked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `lock_country` varchar(2) NOT NULL DEFAULT '00',
  `last_login` timestamp NULL DEFAULT NULL,
  `online` int(10) unsigned NOT NULL DEFAULT '0',
  `expansion` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `mutetime` bigint(20) NOT NULL DEFAULT '0',
  `mutereason` varchar(255) NOT NULL DEFAULT '',
  `muteby` varchar(50) NOT NULL DEFAULT '',
  `locale` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `os` varchar(3) NOT NULL DEFAULT '',
  `recruiter` int(10) unsigned NOT NULL DEFAULT '0',
  `totaltime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COMMENT='Account System';

-- Dumping data for table acore_auth.account: ~3 rows (approximately)
REPLACE INTO `account` (`id`, `username`, `salt`, `verifier`, `session_key`, `totp_secret`, `email`, `reg_mail`, `joindate`, `last_ip`, `last_attempt_ip`, `failed_logins`, `locked`, `lock_country`, `last_login`, `online`, `expansion`, `mutetime`, `mutereason`, `muteby`, `locale`, `os`, `recruiter`, `totaltime`) VALUES
	(1, 'ADMIN', _binary 0xf76bdb2833e3d0992214358e6bbf56d386750ad983cf3cbfb6158d4fe5097712, _binary 0x332cc1f65d59bf88baf7226ca790156f475576117a3413e7d6c5c8ad5d1ba77d, _binary 0x28bd477b53fd2ce99debdda8b109d7fb5f0fdbc186d5b1962b39c415a6ffbffa3faa7bfa5f5694f0, NULL, '', '', '2023-04-22 17:29:59', '127.0.0.1', '127.0.0.1', 0, 0, '00', '2023-04-25 01:31:25', 0, 2, 0, '', '', 6, 'Win', 0, 1612),
	(2, 'PLAYER', _binary 0xe09b3e4a550e08fcf01b66580c7730ac8399256893328cff972e2df6aec5116b, _binary 0x3145895e0f400fa210c267efce8673ebe0b8acf5a5c156fc28dedf2b0817631c, _binary 0x63aa06f05b37448f21e129632a6c71e2dfdb73a481fa653c5216275b7cc9e75c4415f1d876b4bcd1, NULL, '', '', '2023-04-22 17:30:05', '127.0.0.1', '127.0.0.1', 0, 0, '00', '2023-04-25 01:31:57', 0, 2, 0, '', '', 6, 'Win', 0, 856),
	(3, 'HAELIUS', _binary 0xb96ffe938a6ab7b149e90ddb5743113bdf4f0e2f70b1d95415d0eaae09be0466, _binary 0x95216388ac7caf57940f258ab2a7ec2fb1caee5421d18a5c4fd1c4c30ea7e00f, _binary 0xdbe02b3e2ad200ebb1382011c052399d5dc132882767e2e70fc8fe68dd8374361bbd53f9f94ce411, NULL, '', '', '2024-09-03 15:13:18', '213.22.186.33', '213.22.186.33', 0, 0, '00', '2024-09-03 15:30:22', 0, 2, 0, '', '', 0, 'Win', 0, 0);

-- Dumping structure for table acore_auth.account_access
CREATE TABLE IF NOT EXISTS `account_access` (
  `id` int(10) unsigned NOT NULL,
  `gmlevel` tinyint(3) unsigned NOT NULL,
  `RealmID` int(11) NOT NULL DEFAULT '-1',
  `comment` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`,`RealmID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table acore_auth.account_access: ~1 rows (approximately)
REPLACE INTO `account_access` (`id`, `gmlevel`, `RealmID`, `comment`) VALUES
	(1, 3, -1, ''),
	(3, 3, -1, '');

-- Dumping structure for table acore_auth.account_banned
CREATE TABLE IF NOT EXISTS `account_banned` (
  `id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Account id',
  `bandate` int(10) unsigned NOT NULL DEFAULT '0',
  `unbandate` int(10) unsigned NOT NULL DEFAULT '0',
  `bannedby` varchar(50) NOT NULL,
  `banreason` varchar(255) NOT NULL,
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Ban List';

-- Dumping data for table acore_auth.account_banned: ~0 rows (approximately)

-- Dumping structure for table acore_auth.account_muted
CREATE TABLE IF NOT EXISTS `account_muted` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `mutedate` int(10) unsigned NOT NULL DEFAULT '0',
  `mutetime` int(10) unsigned NOT NULL DEFAULT '0',
  `mutedby` varchar(50) NOT NULL,
  `mutereason` varchar(255) NOT NULL,
  PRIMARY KEY (`guid`,`mutedate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='mute List';

-- Dumping data for table acore_auth.account_muted: ~0 rows (approximately)

-- Dumping structure for table acore_auth.autobroadcast
CREATE TABLE IF NOT EXISTS `autobroadcast` (
  `realmid` int(11) NOT NULL DEFAULT '-1',
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `weight` tinyint(3) unsigned DEFAULT '1',
  `text` longtext NOT NULL,
  PRIMARY KEY (`id`,`realmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table acore_auth.autobroadcast: ~0 rows (approximately)

-- Dumping structure for table acore_auth.build_info
CREATE TABLE IF NOT EXISTS `build_info` (
  `build` int(11) NOT NULL,
  `majorVersion` int(11) DEFAULT NULL,
  `minorVersion` int(11) DEFAULT NULL,
  `bugfixVersion` int(11) DEFAULT NULL,
  `hotfixVersion` char(3) DEFAULT NULL,
  `winAuthSeed` varchar(32) DEFAULT NULL,
  `win64AuthSeed` varchar(32) DEFAULT NULL,
  `mac64AuthSeed` varchar(32) DEFAULT NULL,
  `winChecksumSeed` varchar(40) DEFAULT NULL,
  `macChecksumSeed` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`build`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table acore_auth.build_info: ~11 rows (approximately)
REPLACE INTO `build_info` (`build`, `majorVersion`, `minorVersion`, `bugfixVersion`, `hotfixVersion`, `winAuthSeed`, `win64AuthSeed`, `mac64AuthSeed`, `winChecksumSeed`, `macChecksumSeed`) VALUES
	(5875, 1, 12, 1, NULL, NULL, NULL, NULL, '95EDB27C7823B363CBDDAB56A392E7CB73FCCA20', '8D173CC381961EEBABF336F5E6675B101BB513E5'),
	(6005, 1, 12, 2, NULL, NULL, NULL, NULL, NULL, NULL),
	(6141, 1, 12, 3, NULL, NULL, NULL, NULL, NULL, NULL),
	(8606, 2, 4, 3, NULL, NULL, NULL, NULL, '319AFAA3F2559682F9FF658BE01456255F456FB1', 'D8B0ECFE534BC1131E19BAD1D4C0E813EEE4994F'),
	(9947, 3, 1, 3, NULL, NULL, NULL, NULL, NULL, NULL),
	(10505, 3, 2, 2, 'a', NULL, NULL, NULL, NULL, NULL),
	(11159, 3, 3, 0, 'a', NULL, NULL, NULL, NULL, NULL),
	(11403, 3, 3, 2, NULL, NULL, NULL, NULL, NULL, NULL),
	(11723, 3, 3, 3, 'a', NULL, NULL, NULL, NULL, NULL),
	(12340, 3, 3, 5, 'a', NULL, NULL, NULL, 'CDCBBD5188315E6B4D19449D492DBCFAF156A347', 'B706D13FF2F4018839729461E3F8A0E2B5FDC034'),
	(13930, 3, 3, 5, 'a', NULL, NULL, NULL, NULL, NULL);

-- Dumping structure for table acore_auth.ip_banned
CREATE TABLE IF NOT EXISTS `ip_banned` (
  `ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `bandate` int(10) unsigned NOT NULL,
  `unbandate` int(10) unsigned NOT NULL,
  `bannedby` varchar(50) NOT NULL DEFAULT '[Console]',
  `banreason` varchar(255) NOT NULL DEFAULT 'no reason',
  PRIMARY KEY (`ip`,`bandate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Banned IPs';

-- Dumping data for table acore_auth.ip_banned: ~0 rows (approximately)

-- Dumping structure for table acore_auth.logs
CREATE TABLE IF NOT EXISTS `logs` (
  `time` int(10) unsigned NOT NULL,
  `realm` int(10) unsigned NOT NULL,
  `type` varchar(250) NOT NULL,
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `string` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table acore_auth.logs: ~0 rows (approximately)

-- Dumping structure for table acore_auth.logs_ip_actions
CREATE TABLE IF NOT EXISTS `logs_ip_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Unique Identifier',
  `account_id` int(10) unsigned NOT NULL COMMENT 'Account ID',
  `character_guid` int(10) unsigned NOT NULL COMMENT 'Character Guid',
  `type` tinyint(3) unsigned NOT NULL,
  `ip` varchar(15) NOT NULL DEFAULT '127.0.0.1',
  `systemnote` text COMMENT 'Notes inserted by system',
  `unixtime` int(10) unsigned NOT NULL COMMENT 'Unixtime',
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Timestamp',
  `comment` text COMMENT 'Allows users to add a comment',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Used to log ips of individual actions';

-- Dumping data for table acore_auth.logs_ip_actions: ~0 rows (approximately)

-- Dumping structure for table acore_auth.motd
CREATE TABLE IF NOT EXISTS `motd` (
  `realmid` int(11) NOT NULL,
  `text` longtext,
  PRIMARY KEY (`realmid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table acore_auth.motd: ~0 rows (approximately)
REPLACE INTO `motd` (`realmid`, `text`) VALUES
	(-1, 'Welcome to an AzerothCore server.');

-- Dumping structure for table acore_auth.realmcharacters
CREATE TABLE IF NOT EXISTS `realmcharacters` (
  `realmid` int(10) unsigned NOT NULL DEFAULT '0',
  `acctid` int(10) unsigned NOT NULL,
  `numchars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`realmid`,`acctid`),
  KEY `acctid` (`acctid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Realm Character Tracker';

-- Dumping data for table acore_auth.realmcharacters: ~3 rows (approximately)
REPLACE INTO `realmcharacters` (`realmid`, `acctid`, `numchars`) VALUES
	(1, 1, 1),
	(1, 2, 1),
	(1, 3, 1);

-- Dumping structure for table acore_auth.realmlist
CREATE TABLE IF NOT EXISTS `realmlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localAddress` varchar(255) NOT NULL DEFAULT '127.0.0.1',
  `localSubnetMask` varchar(255) NOT NULL DEFAULT '255.255.255.0',
  `port` smallint(5) unsigned NOT NULL DEFAULT '8085',
  `icon` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `flag` tinyint(3) unsigned NOT NULL DEFAULT '2',
  `timezone` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `allowedSecurityLevel` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `population` float NOT NULL DEFAULT '0',
  `gamebuild` int(10) unsigned NOT NULL DEFAULT '12340',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='Realm System';

-- Dumping data for table acore_auth.realmlist: ~0 rows (approximately)
REPLACE INTO `realmlist` (`id`, `name`, `address`, `localAddress`, `localSubnetMask`, `port`, `icon`, `flag`, `timezone`, `allowedSecurityLevel`, `population`, `gamebuild`) VALUES
	(1, 'AzerothCore', '68.221.169.194', '127.0.0.1', '255.255.255.0', 8085, 0, 0, 1, 0, 0, 12340);

-- Dumping structure for table acore_auth.secret_digest
CREATE TABLE IF NOT EXISTS `secret_digest` (
  `id` int(10) unsigned NOT NULL,
  `digest` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Dumping data for table acore_auth.secret_digest: ~0 rows (approximately)

-- Dumping structure for table acore_auth.updates
CREATE TABLE IF NOT EXISTS `updates` (
  `name` varchar(200) NOT NULL COMMENT 'filename with extension of the update.',
  `hash` char(40) DEFAULT '' COMMENT 'sha1 hash of the sql file.',
  `state` enum('RELEASED','CUSTOM','MODULE','ARCHIVED') NOT NULL DEFAULT 'RELEASED' COMMENT 'defines if an update is released or archived.',
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'timestamp when the query was applied.',
  `speed` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'time the query takes to apply in ms.',
  PRIMARY KEY (`name`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='List of all applied updates in this database.';

-- Dumping data for table acore_auth.updates: 34 rows
/*!40000 ALTER TABLE `updates` DISABLE KEYS */;
REPLACE INTO `updates` (`name`, `hash`, `state`, `timestamp`, `speed`) VALUES
	('2021_01_25_00.sql', '5FA7F802E04CBF66848938FE7FC14FC4CC815F3C', 'ARCHIVED', '2021-10-15 00:59:32', 51),
	('2021_03_21_00.sql', '1E98E516DAD70DC101E339950C1BCC1D15BE78B6', 'ARCHIVED', '2021-10-15 00:59:32', 102),
	('2021_03_23_00.sql', '0EA578B7108559B4E54CAE99714F695659EDE6E5', 'ARCHIVED', '2021-10-15 00:59:32', 77),
	('2021_05_13_00.sql', 'B9CABD6897489B20D6523AEDC61AD9075BCA398A', 'ARCHIVED', '2021-10-15 00:59:32', 104),
	('2021_05_26_00.sql', '435822D9482BA2C5F0D8E54E3A587611A453B0FA', 'ARCHIVED', '2021-10-15 00:59:32', 71),
	('2021_05_30_00.sql', 'E70A61123CBE2DC8AF332D03DF1889EB0DF3CEAB', 'ARCHIVED', '2021-10-15 00:59:32', 64),
	('2021_06_17_00.sql', '36686970C025046FD49FA4BF6F8283A1AE2BE8F3', 'ARCHIVED', '2021-10-15 00:59:33', 52),
	('2016_08_25_01.sql', 'A5A2BE04C8E8E85CD177B8684DFFEACF71C9CF69', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2016_07_09_00.sql', 'B692C4D5E96D26616E1E655D99DD27F6AC4FFDA6', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2019_04_13_00.sql', '183C28E079DAB46AD6F7C0617E19346CAD043141', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2016_09_04_00.sql', '420ACF7160BF5549BC298EB6A1319969789DA140', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2017_08_19_00.sql', 'E4457FFFFC0D3F86750F07CF88F549529E1B27E5', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2016_08_25_00.sql', '707016C338350676C814D7926DFB6081E57091C3', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2016_07_09_01.sql', 'DE551E4708FE31AAC60CEF69466BBC5DFAC46F79', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2016_07_10_00.sql', '0AE2F7FB1E9C1E2BC2870D0EB817F3C87E0A39B3', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2016_11_18_00.sql', '92D22B3A45466470239402367D94C3791A243EF7', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2016_11_19_00.sql', 'C55E73648F661F40237B03F266F7169D231B3D8D', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2017_08_20_01.sql', 'E6190311E1A12E259C6CD21ACFC8BAA1D3F597DF', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2017_12_05_00.sql', '475860B881DE6E9CAC93AD3B37E7AAA8D63FB1B9', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2018_01_21_00.sql', '570FC5FC653D81B0E498E3EAB6706C9868CE8079', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2018_09_17_00.sql', '31743E771FFA4C92D6B6CF747DE4302814BDF257', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2019_01_05_00.sql', '2449121ABB0D5004BF6941B340F5C294AD95EBE9', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2019_02_08_00.sql', '18FF48FC1B1C238D44198FA1E2D422BAB4C9C338', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2019_02_17_00.sql', '1F4C4A15313A261088E40909DCCAA068EAAAAAAE', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2020_02_07_00.sql', '9549BF7354B4FA5A661EC094A2C3AAF665678152', 'ARCHIVED', '2021-10-14 07:13:44', 1),
	('2021_10_14_00.sql', 'D4378AFC454DF8351A6DE6C6B6144F82C62980A5', 'ARCHIVED', '2021-10-15 00:59:33', 53),
	('2021_10_14_01_auth.sql', 'A4495131ADD2AB4AB6682C1621683963247368F0', 'ARCHIVED', '2022-01-22 02:36:20', 20),
	('2021_11_06_00.sql', 'E08D11C492289879C460BB063457DAD968545752', 'ARCHIVED', '2022-01-22 02:36:20', 39),
	('2022_01_23_00.sql', '6291006CD2B38EEE02EDDD8AEB6A952477854C77', 'ARCHIVED', '2022-04-24 18:19:14', 28),
	('2022_04_24_00.sql', 'CFB8D5B896B2A5900F5E5A2262B356E0842405BB', 'ARCHIVED', '2022-08-21 12:56:35', 34),
	('2022_04_28_00.sql', '26108CBD35D4B885A90CEC25665DCBC00FD06809', 'ARCHIVED', '2022-08-21 12:56:35', 30),
	('2022_08_21_00.sql', 'E333B1A3FD1A25298D29B8FCAA0EE8AE5985202F', 'ARCHIVED', '2023-01-31 23:19:58', 28),
	('2023_01_31_00.sql', '0ACDD35EC9745231BCFA701B78056DEF94D0CC53', 'RELEASED', '2023-04-22 17:10:38', 52),
	('2023_02_20_00.sql', 'B2A8F337A3699322D19729AF07ADC5607FAEEF83', 'RELEASED', '2023-04-22 17:10:39', 589);
/*!40000 ALTER TABLE `updates` ENABLE KEYS */;

-- Dumping structure for table acore_auth.updates_include
CREATE TABLE IF NOT EXISTS `updates_include` (
  `path` varchar(200) NOT NULL COMMENT 'directory to include. $ means relative to the source directory.',
  `state` enum('RELEASED','ARCHIVED','CUSTOM') NOT NULL DEFAULT 'RELEASED' COMMENT 'defines if the directory contains released or archived updates.',
  PRIMARY KEY (`path`) USING BTREE
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='List of directories where we want to include sql updates.';

-- Dumping data for table acore_auth.updates_include: 3 rows
/*!40000 ALTER TABLE `updates_include` DISABLE KEYS */;
REPLACE INTO `updates_include` (`path`, `state`) VALUES
	('$/data/sql/updates/db_auth', 'RELEASED'),
	('$/data/sql/custom/db_auth', 'CUSTOM'),
	('$/data/sql/archive/db_auth', 'ARCHIVED');
/*!40000 ALTER TABLE `updates_include` ENABLE KEYS */;

-- Dumping structure for table acore_auth.uptime
CREATE TABLE IF NOT EXISTS `uptime` (
  `realmid` int(10) unsigned NOT NULL,
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `uptime` int(10) unsigned NOT NULL DEFAULT '0',
  `maxplayers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `revision` varchar(255) NOT NULL DEFAULT 'AzerothCore',
  PRIMARY KEY (`realmid`,`starttime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Uptime system';

-- Dumping data for table acore_auth.uptime: ~5 rows (approximately)
REPLACE INTO `uptime` (`realmid`, `starttime`, `uptime`, `maxplayers`, `revision`) VALUES
	(1, 1550400304, 121, 0, 'AzerothCore rev. 2bcedc2859e7 2019-02-17 10:04:09 +0100 (master branch) (Unix, Debug)'),
	(1, 1550400454, 1440, 0, 'AzerothCore rev. 2bcedc2859e7 2019-02-17 10:04:09 +0100 (master branch) (Unix, Debug)'),
	(1, 1661068597, 0, 0, 'AzerothCore rev. 5d6dfca80cf1 2022-08-21 09:48:09 +0200 (new-squash-POGGIES branch) (Win64, RelWithDebInfo, Static)'),
	(1, 1675207201, 0, 0, 'AzerothCore rev. e7cbc80a913b 2023-01-31 22:22:22 +0000 (master branch) (Win64, RelWithDebInfo, Static)'),
	(1, 1682184538, 0, 0, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1682187251, 750, 1, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1682189288, 107, 0, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1682196089, 524, 1, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1682201213, 173, 1, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1682238620, 395, 1, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1682272842, 3124, 1, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1682276038, 147, 1, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1682385658, 934, 2, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)'),
	(1, 1725376254, 2852, 1, 'AzerothCore rev. 96a5224d927f+ 2023-04-22 07:25:31 +0700 (npcbots_3.3.5 branch) (Win64, Release, Static)');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
